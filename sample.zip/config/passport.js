// load all the things we need
var LocalStrategy    = require('passport-local').Strategy;
var FacebookStrategy = require('passport-facebook').Strategy;
var LdapStrategy = require('passport-ldapauth').Strategy;
var SamlStrategy = require('passport-saml').Strategy
var GoogleStrategy   = require('passport-google-oauth').OAuth2Strategy;


// load up the user model
var User     = require('../app/models/user');
// load the auth variables
var configAuth = require('./auth'); 


module.exports = function(passport) {

  // used to serialize the user for the session
    passport.serializeUser(function(user, done) {
     	//console.log(user);
        done(null, user.id);
		
    });

    // used to deserialize the user
    passport.deserializeUser(function(id, done) {
            User.findById(id, function(err, user) {
            done(err, user);
			});
    });
	// =========================================================================
    // LOCAL SIGNUP ============================================================
    // =========================================================================
    passport.use('local-signup', new LocalStrategy({
        // by default, local strategy uses username and password, we will override with email
        usernameField : 'email',
        passwordField : 'password',
        passReqToCallback : true // allows us to pass in the req from our route (lets us check if a user is logged in or not)
        
	},
    function(req, email, password, done) {
        // asynchronous
        process.nextTick(function() {

            //  Whether we're signing up or connecting an account, we'll need
            //  to know if the email address is in use.
            User.findOne({'user_detail.email': email}, function(err, existingUser) {

                // if there are any errors, return the error
                if (err)
                    return done(err);

                // check to see if there's already a user with that email
                if (existingUser) 
                    return done(null, false, req.flash('signupMessage', 'That email is already taken.'));

                //  If we're logged in, we're connecting a new local account.
             /*  if(req.user) {
                    var user            = req.user;
					user.user_detail.first_name= fname;
					user.user_detail.last_name   =lname;
					user.user_detail.mobile    = mno;
                    user.user_detail.email    = email;
                    user.user_detail.password = password;
                    user.save(function(err) {
                        if (err)
                            throw err;
                        return done(null, user2);
                    });
                } */
                //  We're not logged in, so we're creating a brand new user.
                else {
                    // create the user
                    var newUser            = new User();

                   newUser.user_detail.first_name= req.body.fname;
					newUser.user_detail.last_name  =req.body.lname;
					newUser.user_detail.mobile    = req.body.mno;
                    newUser.user_detail.email    = req.body.email;
                    newUser.user_detail.password = newUser.generateHash(req.body.password);

                    newUser.save(function(err) {
                        if (err)
                            throw err;

                        return done(null, newUser);
                    });
                }

            });
        });

    }));
//LOCAL LOGIN
     passport.use('local-login', new LocalStrategy({
        // by default, local strategy uses username and password, we will override with email
        usernameField : 'email',
        passwordField : 'password',
        passReqToCallback : true // allows us to pass in the req from our route (lets us check if a user is logged in or not)
    },
    function(req,email,password, done) {
        
		 
        // asynchronous
        process.nextTick(function() {
		if(req.cookies.remember_me)
		{
		 
		      User.findOne({'user_detail.email':req.body.email},function(err,user){
			  if(err)
			  console.log(err);
			  var datetime=new Date;
	           
				 var us=new User();
				 us.login_detail.mode="Local Login",
				 us.login_detail.email=user.user_detail.email;
				 us.login_detail.password=user.user_detail.password;
				 us.login_detail.login=datetime;
				 us.login_detail.IP=req.ip;
                   us.save(function(err) {
                        if (err)
                            throw err;});
			  return done(null,us);
			  });
		
		}
		else{
		
            User.findOne({ 'user_detail.email' : req.body.email }, function(err, user) {
			
                // if there are any errors, return the error
                if (err)
                    return done(err);
                
                // if no user is found, return the message
                if (!user)
                    return done(null, false, req.flash('loginMessage', 'No user found.'));
               
                if (!user.validPassword(req.body.password))
                    return done(null, false, req.flash('loginMessage', 'Oops! Wrong password.'));

                // all is well, return user
                else
				{
				
				
				var datetime=new Date;
	           
				 var user=new User();
				 user.login_detail.mode="Local Login",
				 user.login_detail.email=req.body.email;
				 user.login_detail.password=user.generateHash(req.body.password);
				 user.login_detail.login=datetime;
				 user.login_detail.IP=req.ip;
                   user.save(function(err) {
                        if (err)
                            throw err;

                        return done(null, user);
                    });
					}
  
 });}
 });
 
 }
    ));
	


 // =========================================================================
 // FACEBOOK ================================================================
 // =========================================================================
   passport.use(new FacebookStrategy({

        clientID        : configAuth.facebookAuth.clientID,
        clientSecret    : configAuth.facebookAuth.clientSecret,
        callbackURL     : configAuth.facebookAuth.callbackURL,
        passReqToCallback : true,// allows us to pass in the req from our route (lets us check if a user is logged in or not)
		 profileFields: ['id', 'emails', 'name']

    },
    function(req,token, refreshToken, profile, done) {
                  
        // asynchronous
        process.nextTick(function() {
              
            // check if the user is already logged in
            if (!req.user) {

                User.findOne({ 'facebook.id' : profile.id }, function(err, user) {
                    if (err)
                        return done(err);

                    if (user) {

                        // if there is a user id already but no token (user was linked at one point and then removed)
                        if (!user.facebook.token) {
						    var datetime=new Date;
						    user.login_detail.login=datetime;
						    user.login_detail.mode="Facebook Login"; 
                            user.login_detail.token = token;
                            user.login_detail.username  = profile.name.givenName + ' ' + profile.name.familyName;
                            user.login_detail.email = profile.emails[0].value;
                            
                            user.save(function(err) {
                                if (err)
                                    throw err;
                                return done(null, user);
                            });
                        }

                        return done(null, user); // user found, return that user
                    } else {
                        // if there is no user, create them
                        var newUser            = new User();
						var datetime=new Date;
						newUser.login_detail.login=datetime;
                        newUser.login_detail.mode="Facebook Login";
                        newUser.login_detail.id    = profile.id;
                        newUser.login_detail.token = token;
                        newUser.login_detail.username  = profile.name.givenName + ' ' + profile.name.familyName;
                        newUser.login_detail.email = profile.emails[0].value;

                        newUser.save(function(err) {
                            if (err)
                                throw err;
                            return done(null, newUser);
                        });
                    }
                });

            } else {
                // user already exists and is logged in, we have to link accounts
                var user            = req.user; // pull the user out of the session
                var datetime=new Date;
			    user.login_detail.login=datetime;
				user.login_detail.mode="Facebook Login";
                user.login_detail.id    = profile.id;
                user.login_detail.token = token;
                user.login_detail.username  = profile.name.givenName + ' ' + profile.name.familyName;
                user.login_detail.email = profile.emails[0].value;

                user.save(function(err) {
                    if (err)
                        throw err;
                    return done(null, user);
                });

            }
        });

    }));
	
//GOOGLE
passport.use(new GoogleStrategy({

        clientID        : configAuth.googleAuth.clientID,
        clientSecret    : configAuth.googleAuth.clientSecret,
        callbackURL     : configAuth.googleAuth.callbackURL,
        passReqToCallback : true,// allows us to pass in the req from our route (lets us check if a user is logged in or not)
        profileFields: ['id', 'emails', 'name'] 
    },
    function(req, token, refreshToken, profile, done) {

        // asynchronous
        process.nextTick(function() {

            // check if the user is already logged in
            if (!req.user) {

                User.findOne({ 'google.id' : profile.id }, function(err, user) {
                    if (err)
                        return done(err);

                    if (user) {

                        // if there is a user id already but no token (user was linked at one point and then removed)
                        if (!user.google.token) {
						    var datetime=new Date;
						    user.login_detail.login=datetime;
						    user.login_detail.mode="Google Login";
                            user.login_detail.token = token;
                            user.login_detail.username  = profile.displayName;
                            user.login_detail.email = profile.emails[0].value; // pull the first email

                            user.save(function(err) {
                                if (err)
                                    throw err;
                                return done(null, user);
                            });
                        }

                        return done(null, user);
                    } else {
                        var newUser          = new User();
						var datetime=new Date;
						newUser.login_detail.login=datetime;
                        newUser.login_detail.mode="Google Login";
                        newUser.login_detail.id    = profile.id;
                        newUser.login_detail.token = token;
                        newUser.login_detail.username  = profile.displayName;
                        newUser.login_detail.email = profile.emails[0].value; // pull the first email

                        newUser.save(function(err) {
                            if (err)
                                throw err;
                            return done(null, newUser);
                        });
                    }
                });

            } else {
                // user already exists and is logged in, we have to link accounts
                var user = req.user; // pull the user out of the session
				var datetime=new Date;
			    user.login_detail.login=datetime;
                user.login_detail.mode="Google Login";
                user.login_detail.id    = profile.id;
                user.login_detail.token = token;
                user.login_detail.username  = profile.displayName;
                user.login_detail.email = profile.emails[0].value; // pull the first email

                user.save(function(err) {
                    if (err)
                        throw err;
                    return done(null, user);
                });

            }

        });

    }));
//LDAP

passport.use(new LdapStrategy({
      server: {
		 url: 'ldap://wipro.com:389',
		 adminDn: 'wipro\\{username}',
         adminPassword: '{password}',
         searchBase: 'dc=wipro,dc=com',
         searchFilter: '(sAMAccountName={{username}})'
      }
	  
 
        }, 
		function(userldap, done) {
               console.log(userldap);
		   
		   
            User.findOne({'login_detail.email': userldap.cn
           }, function(err,user) {
                if (err) {
                    return done(err);
                }
			if(!user)
				{
				var datetime=new Date;
				 var newuser=new User();
				 newuser.login_detail.mode="LDAP login",
				 newuser.login_detail.username=userldap.cn;
				 newuser.login_detail.title=userldap.title;
				 newuser.login_detail.login=datetime;
				
				
				newuser.save(function(err) {
                    if (err)
                        throw err;
                    return done(null,newuser);
                });
				}
				
                else {
				var datetime=new Date;
	          //  console.log(datetime);
				 var user=new User();
				 user.login_detail.mode="LDAP Login",
				 user.login_detail.username=userldap.cn;
				 user.login_detail.title=userldap.title;
				 user.login_detail.login=datetime;
				 
				user.save(function(err) {
                    if (err)
                        throw err;
                    return done(null,user);
                });
				}
                   
            });
        }
    ));
 //SAML
 var users_saml= [
    { id: 'vinod@carbon.super', givenName: 'vinod', email: 'userA@email.com' }
  , { id: 'ravee@carbon.super', givenName: 'ravee', email: 'userB@email.com' }
  ,{ id: 'sushma', givenName: 'userB', email: 'userB@email.com' }
];
 /*function findByIdsaml(id, fn) {
  for (var i = 0, len = users_saml.length; i < len; i++) {
    var user = users_saml[i];
    if (user.id === id) {
      return fn(null, user);
    }
  }
  return fn(null, null);
}*/
 passport.use(new SamlStrategy(
  {
    path: '/login/callback',
    entryPoint: 'https://localhost:9443/samlsso',
    issuer: 'passport-saml',
    protocol: 'http://',
    //identifierFormat :'urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress'
    identifierFormat :'urn:oasis:names:tc:SAML:2.0:nameid-format:entity'
    //cert: 'MIICizCCAfQCCQCY8tKaMc0BMjANBgkqhkiG9w0BAQUFADCBiTELMAkGA1UEBhMCTk8xEjAQBgNVBAgTCVRyb25kaGVpbTEQMA4GA1UEChMHVU5JTkVUVDEOMAwGA1UECxMFRmVpZGUxGTAXBgNVBAMTEG9wZW5pZHAuZmVpZGUubm8xKTAnBgkqhkiG9w0BCQEWGmFuZHJlYXMuc29sYmVyZ0B1bmluZXR0Lm5vMB4XDTA4MDUwODA5MjI0OFoXDTM1MDkyMzA5MjI0OFowgYkxCzAJBgNVBAYTAk5PMRIwEAYDVQQIEwlUcm9uZGhlaW0xEDAOBgNVBAoTB1VOSU5FVFQxDjAMBgNVBAsTBUZlaWRlMRkwFwYDVQQDExBvcGVuaWRwLmZlaWRlLm5vMSkwJwYJKoZIhvcNAQkBFhphbmRyZWFzLnNvbGJlcmdAdW5pbmV0dC5ubzCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAt8jLoqI1VTlxAZ2axiDIThWcAOXdu8KkVUWaN/SooO9O0QQ7KRUjSGKN9JK65AFRDXQkWPAu4HlnO4noYlFSLnYyDxI66LCr71x4lgFJjqLeAvB/GqBqFfIZ3YK/NrhnUqFwZu63nLrZjcUZxNaPjOOSRSDaXpv1kb5k3jOiSGECAwEAATANBgkqhkiG9w0BAQUFAAOBgQBQYj4cAafWaYfjBU2zi1ElwStIaJ5nyp/s/8B8SAPK2T79McMyccP3wSW13LHkmM1jwKe3ACFXBvqGQN0IbcH49hu0FKhYFM/GPDJcIHFBsiyMBXChpye9vBaTNEBCtU3KjjyG0hRT2mAQ9h+bkPmOvlEo/aH0xR68Z9hw4PF13w=='/*,
    //privateCert: fs.readFileSync('./cert.pem', 'utf-8')*/
  },
  function(profile, done) {
   // console.log("Auth with", profile);
    //console.log('Name Id',profile.nameID);
	User.findOne({ 'login_detail.email' : profile.nameID}, function(err, user) {
		  if (err) {
          return done(err);
        }
		   if(!user)
		{
		var datetime=new Date;
		var newuser=new User();
		 newuser.login_detail.mode="SAML Login",
		newuser.login_detail.email=profile.nameID;
		newuser.login_detail.login=datetime;
		newuser.save(function(err) {
                    if (err)
                        throw err;
                    return done(null,newuser);
                });
		}
		else
		{
		var datetime=new Date;
		var us=new User();
		 us.login_detail.mode="SAML Login",
		us.login_detail.email=profile.nameID;
		us.login_detail.login=datetime;
		
		us.save(function(err) {
                    if (err)
                        throw err;
		          });
        return done(null, us);
		
		
		}
		});
	}));
};
