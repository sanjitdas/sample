// config/database.js
module.exports = {

    'url' : 'mongodb://localhost/integ_db'

};
