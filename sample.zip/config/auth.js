// config/auth.js

// expose our config directly to our application using module.exports
module.exports = {

    'facebookAuth' : {
        'clientID'      : '944274385691309', // your App ID
        'clientSecret'  : '4e0a01eafae02a7e1a128f3d0c08e928', // your App Secret
        'callbackURL'   : 'http://localhost:5000/auth/facebook/callback'
    },
    

    'googleAuth' : {
        'clientID'      : '593005629590-n9c07r4tmv686n0ppgoaka11cdvn6ol6.apps.googleusercontent.com',
        'clientSecret'  : 'hk8qEnrJxlZHHdAaKuAmd2W0',
        'callbackURL'   : 'http://localhost:5000/auth/google/callback'
    }

};