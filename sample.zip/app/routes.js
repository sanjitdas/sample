var User     = require('../app/models/user');
var nodemailer = require('nodemailer');
var async = require('async');
var crypto = require('crypto');


module.exports = function(app,passport) {
// normal routes ===============================================================
 
	// show the home page (will also have our login links)
	app.get('/', function(req, res) {
		res.render('login.ejs');
	});
	app.get('/error', function(req, res) {
		res.render('error.ejs');
	});
	// PROFILE SECTION =========================
	app.get('/profile1',isLoggedIn,function(req, res) {
		res.render('profile1.ejs', {
			user : req.user
		});
	});
	app.get('/profile2',isLoggedIn, function(req, res) {
		res.render('profile2.ejs', {
			user : req.user
		});
	});
	app.get('/welcome',isLoggedIn, function(req, res) {
		res.render('welcome.ejs', {
			user : req.user
		});
		});
	app.get('/fbprofile',isLoggedIn, function(req, res) {
		res.render('fbprofile.ejs', {
			user : req.user
		});
		});
    app.get('/googleprofile',isLoggedIn, function(req, res) {
		res.render('googleprofile.ejs', {
			user : req.user
		});
		});
	app.get('/ldaplogin', function(req, res) {
		res.render('ldaplogin.ejs',{
			user : req.user
		});
	});
	
   // LOGOUT ==============================
	app.get('/logout', function(req, res) {
		var datetime=new Date;
		//console.log(req.user._id);
		
		User.findById(req.user._id, function(err, p) {
		if(err)
		throw err;
		else
		{
		  p.login_detail.logout=datetime;
		  p.save(function(err) {
      if (err)
        throw err;
     
    });
		  }
			});		
			       res.clearCookie('remember_me');
					req.session.destroy(function(){
					res.cookie('connect.sid', '', { path: '/'});	
                     res.redirect('/');});	
				req.logout();
	});
//CHANGE PASSWORD
app.get('/change', function(req, res) {
  res.render('chpwd.ejs', {
    user: req.user
  });
});
app.post('/change',function(req,res){

  User.findOne({'user_detail.email':req.body.id}, function(err, p) {
		if(err)
		throw err;
		else
		{
		  
		if(p.validPassword(req.body.password))
		    res.render('reset.ejs', {
              user: p
  });
		else
		   res.render('error.ejs');
		}});
});
app.post('/reset',function(req,res){
User.findOne({'user_detail.email':req.body.id}, function(err, p) {
		if(err)
		throw err;
		else
		{
		  
		   p.user_detail.password=p.generateHash(req.body.newpwd);
		   p.save(function(err) {
      if (err)
        throw err;
     
    });}
  });
	  res.redirect('/');	
		});

//FORGOT PASSWORD
app.get('/forgot', function(req, res) {
  res.render('forgot.ejs', {
    user: req.user
  });
});
app.post('/forgot', function(req, res, next) {
  async.waterfall([
    function(done) {
      crypto.randomBytes(20, function(err, buf) {
        var token = buf.toString('hex');
        done(err, token);
      });
    },
    function(token, done) {
      User.findOne({ 'user_detail.email': req.body.uname }, function(err, user) {
        if (!user) {
          req.flash('error', 'No account with that email address registered.');
          return res.redirect('/forgot');
        }

        user.user_detail.resetPasswordToken = token;
        user.user_detail.resetPasswordExpires = Date.now() + 3600000; // 1 hour

        user.save(function(err) {
          done(err, token, user);
        });
      });
    },
    function(token, user, done) {
	
      var smtpTransport = nodemailer.createTransport('SMTP', {
	     
         service:'SendGrid',
         auth: {
          user: 'ravee44',
          pass: 'raveesingh44'
        }
		
		
		
	    
      });
	console.log(req.headers.host,token);
      var mailOptions = {
        to: req.body.email,
        from: 'raveesingh140@gmail.com',
        subject: 'Node.js Password Reset',
        text: 'You are receiving this because you (or someone else) have requested the reset of the password for your account.\n\n' +
          'Please click on the following link, or paste this into your browser to complete the process:\n\n' +
          'http://' + req.headers.host + '/reset/' + token + '\n\n' +
          'If you did not request this, please ignore this email and your password will remain unchanged.\n'
      };
      smtpTransport.sendMail(mailOptions, function(err) {
	 
        req.flash('info', 'An e-mail has been sent to ' +req.body.email  + ' with further instructions.');
        done(err, 'done');
      });
 } ], function(err) {
    if (err) return next(err);
    res.redirect('/forgot');
  });
}); 
app.get('/reset/:token', function(req, res) {
  User.findOne({ 'user_detail.resetPasswordToken': req.params.token, resetPasswordExpires: { $gt: Date.now() } }, function(err, user) {
    if (!user) {
      req.flash('error', 'Password reset token is invalid or has expired.');
      return res.redirect('/forgot');
    }
    res.render('reset.ejs', {
      user: req.user
    });
  });
});
app.post('/reset/:token', function(req, res) {
  async.waterfall([
    function(done) {
      User.findOne({ 'user_detail.resetPasswordToken': req.params.token, resetPasswordExpires: { $gt: Date.now() } }, function(err, user) {
        if (!user) {
          req.flash('error', 'Password reset token is invalid or has expired.');
          return res.redirect('back');
        }

        user.user_detail.password = req.body.password;
        user.user_detail.resetPasswordToken = undefined;
        user.user_detail.resetPasswordExpires = undefined;

        user.save(function(err) {
          req.logIn(user, function(err) {
            done(err, user);
          });
        });
      });
    },
    function(user, done) {
      var smtpTransport = nodemailer.createTransport('SMTP', {
         service:'SendGrid',
         auth: {
          user: 'ravee44',
          pass: 'raveesingh44'
        }
      });
      var mailOptions = {
        to: user.email,
        from: 'raveesingh140@gmail.com',
        subject: 'Your password has been changed',
        text: 'Hello,\n\n' +
          'This is a confirmation that the password for your account ' + user.email + ' has just been changed.\n'
      };
      smtpTransport.sendMail(mailOptions, function(err) {
        req.flash('success', 'Success! Your password has been changed.');
        done(err);
      });
    }
  ], function(err) {
    res.redirect('/');
  });
});
// SIGNUP =================================
	   // show the signup form
		app.get('/signup', function(req, res) {
			res.render('signup.ejs', { message: req.flash('loginMessage') });
		});
		// process the signup form
		app.post('/signup', passport.authenticate('local-signup', {
			successRedirect : '/', // redirect to the secure profile section
			failureRedirect : '/error', // redirect back to the signup page if there is an error
			failureFlash : true // allow flash messages
		}));
// LOCAL LOGIN ===============================
		// show the login form
	 //   app.get('/locallogin', function(req, res) {
			
	//	});
      //  app.get('/locallogin', passport.authenticate('local-login'));
		// process the login form
		app.post('/locallogin', passport.authenticate('local-login', {
			
			failureRedirect : '/error', // redirect back to the signup page if there is an error
			failureFlash : true}),// allow flash messages
			function(req, res, next) {
    // Issue a remember me cookie if the option was checked
    //console.log(req);
    if(req.body.remember)
	{
	
	
	res.cookie('remember_me',req.body.email,{maxAge: 60 * 60 * 1000});
	return next();
	}
	return next();
   },
  function(req, res) {
    res.redirect('/profile1');
  });
  

// FACEBOOK -------------------------------

		// send to facebook to do the authentication
	app.get('/auth/facebook', passport.authenticate('facebook', { scope : 'email' }));

		// handle the callback after facebook has authenticated the user
		app.get('/auth/facebook/callback',passport.authenticate('facebook', {
				successRedirect : '/fbprofile',
				failureRedirect : '/error'
		}));
//GOOGLE

		// send to google to do the authentication
		app.get('/auth/google', passport.authenticate('google', { scope : ['profile', 'email'] }));

		// the callback after google has authenticated the user
		app.get('/auth/google/callback',
			passport.authenticate('google', {
				successRedirect : '/googleprofile',
				failureRedirect : '/error'
			}));
//LDAP
     // send to wipro to do the authentication
		app.get('/ldap', function(req, res) {
			res.render('ldaplogin.ejs', { message: req.flash('loginMessage') });
		});
		// process the signup form
		app.post('/ldap', passport.authenticate('ldapauth', {
			successRedirect : '/profile2', // redirect to the secure profile section
			failureRedirect : '/error', // redirect back to the signup page if there is an error
			failureFlash : true // allow flash messages
		}));
//SAML


	app.post('/login/callback',
  passport.authenticate('saml', { failureRedirect: '/callback_error', failureFlash: true }),
  function(req, res) {
    res.redirect('/welcome');
  }
);	
		
		app.get('/idp',
     passport.authenticate('saml', { 
	 successRedirect : '/welcome',
	 failureRedirect: '/error', 
	 failureFlash: true,
	 samlFallback:'login-request' })
     
        
  );

	// route middleware to ensure user is logged in
function isLoggedIn(req, res, next) {
//console.log(req.user._id);
	if (req.isAuthenticated())
	{
	User.findById(req.user._id, function(err, p) {
		if(err)
		throw err;
		else
		{
		  p.login_detail.IP=req.ip;
		  p.login_detail.browser=req.headers['user-agent'];
		  p.save(function(err) {
      if (err)
        throw err;
    });
		  }
			});		
		return next();
}
	res.redirect('/');


	}


};