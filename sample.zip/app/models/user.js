// app/models/user.js
// load the things we need
var mongoose = require('mongoose');
var bcrypt   = require('bcrypt-nodejs');
// define the schema for our user model
var userSchema = mongoose.Schema({
     user_detail:      {
	     first_name   :String,
	     last_name    :String,
	     mobile       :String,
	     email        :String,
	     password     :String,
		 token        :String
	  },
    login_detail        : {
	    id           : String,
	    mode         : String,
        email        : String,
        password     : String,
		login        : String,
		logout       : String,
		IP           : String,
		title        : String,
		token        : String,
		username     : String,
		browser      : String
	  
    }
	

},{collection:'user_info'});
//generating random token

// generating a hash
userSchema.methods.generateHash = function(password) {
    return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null);
};
// checking if password is valid
userSchema.methods.validPassword = function(password) {
    return bcrypt.compareSync(password, this.user_detail.password);
};
// create the model for users and expose it to our app
module.exports = mongoose.model('User', userSchema);
